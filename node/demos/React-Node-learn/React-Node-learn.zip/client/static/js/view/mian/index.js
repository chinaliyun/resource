var React = require('react');
var ReactDOM = require('react-dom');
var store = require('../../store/main/index.js');

class MessageList extends React.Component{
	constructor(props){
		super(props);
		this.state = {
			MessageList: []
		};
		this.getData();
	}
	render(){
		var self = this;
		var messages = this.state.MessageList;
		var arr = [];

		messages.forEach(function(em){
			arr.push(<li key={em}>{em}</li>)
		})
		return <section clasName="pageContentInner">
			<ul>
				{arr}
			</ul>
		</section>
	}
	getData(){
		var self = this;
		store.getAllData(function(data){
			var i = 0;
			var len = data.length;
			var messageLIstArr = [];
			for(;i<len; i++){
				messageLIstArr[i] = data[i].Message
			}
			self.setState({messageList: messageLIstArr});
			console.log(self.state.messageList)
		})
	}
}
ReactDOM.render(
	<MessageList />,
	  document.getElementById('main-container')
)