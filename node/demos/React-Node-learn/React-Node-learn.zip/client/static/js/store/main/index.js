var EventEmitter = require('events').EventEmitter;

class Store_messageList extends EventEmitter{
	constructor(){
		this.allData = null
	}
	getAllData(callback){
		var self = this;
		fetch('/data/getMessage')
			.then(function(res){
				if(res.ok){
					res.json().then(function(data){
						self.allData = data;
						callback(self.allData);
					})
				}else{
					console.log('error')
				}
			},function(e){
				console.log('fetch faild',e)
			})
	}
}
module.exports = new Store_messageList();